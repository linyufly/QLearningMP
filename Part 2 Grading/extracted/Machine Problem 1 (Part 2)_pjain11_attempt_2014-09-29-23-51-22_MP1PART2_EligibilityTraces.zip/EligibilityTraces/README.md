<<<<<<< HEAD
Q-Learning
==========
=======
Eligibility-Traces
==================
>>>>>>> 17fac72f11120f6401fbdbb84a4d06cb526341dc
